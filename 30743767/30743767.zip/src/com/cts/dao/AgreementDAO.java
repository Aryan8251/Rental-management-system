package com.cts.dao;

import com.cts.db.DBConnection;
import com.cts.model.Property;
import com.cts.model.RentalAgreement;
import com.cts.model.Tenant;
import com.cts.services.PropertyServices;
import com.cts.services.TenantServices;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;

public class AgreementDAO {

    PropertyServices propertyServices = new PropertyServices();
    TenantServices tenantServices = new TenantServices();

    public List<RentalAgreement> getAll() throws Exception {
        Connection conn = DBConnection.getConnection();
        String sql = "select * from rental_agreement";
        PreparedStatement ps = conn.prepareStatement(sql);
        ResultSet rs = ps.executeQuery();
        List<RentalAgreement> list = new ArrayList<RentalAgreement>();
        while (rs.next()) {
            int id = rs.getInt("agreement_id");

            int propertyId = rs.getInt("property_id");
            Property property = propertyServices.getProperty(propertyId);

            int tenantId = rs.getInt("tenant_id");
            Tenant tenant = tenantServices.getTenant(tenantId);

            LocalDate startDate = LocalDate.parse(rs.getString("start_date"));
            LocalDate endDate = LocalDate.parse(rs.getString("end_date"));
            int depositAmount = rs.getInt("deposit_amount");
            String status = rs.getString("status");
            list.add(new RentalAgreement(id, property, tenant, startDate, endDate, depositAmount, status));
        }
        return list;
    }

    public RentalAgreement getAgreement(int id) throws Exception {
        Connection conn = DBConnection.getConnection();
        String sql = "select * from rental_agreement where agreement_id=" + id;
        PreparedStatement ps = conn.prepareStatement(sql);
        ResultSet rs = ps.executeQuery();
        if (rs.next()) {
            int agreementId = rs.getInt("agreement_id");
            int propertyId = rs.getInt("property_id");
            Property property = propertyServices.getProperty(propertyId);
            int tenantId = rs.getInt("tenant_id");
            Tenant tenant = tenantServices.getTenant(tenantId);
            LocalDate startDate = LocalDate.parse(rs.getString("start_date"));
            LocalDate endDate = LocalDate.parse(rs.getString("end_date"));
            int depositAmount = rs.getInt("deposit_amount");
            String status = rs.getString("status");
            return new RentalAgreement(agreementId, property, tenant, startDate, endDate, depositAmount, status);
        }
        return null;
    }

    public void createAgreement(RentalAgreement agreement) throws Exception {
        try {
            Connection conn = DBConnection.getConnection();
            String sql = "Insert into rental_agreement(property_id, tenant_id, start_date, end_date, rent_amount, deposit_amount, status) values(?,?,?,?,?,?,?)";
            PreparedStatement ps = conn.prepareStatement(sql);
            ps.setInt(1, agreement.getProperty().getId());
            ps.setInt(2, agreement.getTenant().getId());
            ps.setString(3, agreement.getStartDate().toString());
            ps.setString(4, agreement.getEndDate().toString());
            ps.setInt(5, agreement.getRentTotalAmount());
            ps.setInt(6, agreement.getDepositAmount());
            ps.setString(7, agreement.getStatus());
            ps.executeUpdate();
            conn.commit();
            System.out.println("Agreement created");
        } catch (Exception e) {
            System.out.println("SQL : " + e.getMessage());
        }
    }

    public void deleteAgreement(int id) throws Exception {
        Connection conn = DBConnection.getConnection();
        String sql = "delete from rental_agreement where agreement_id=" + id;
        PreparedStatement ps = conn.prepareStatement(sql);
        ps.executeUpdate();
        System.out.println("Agreement deleted!!!");
        conn.commit();
    }

    public void updateAgreement(RentalAgreement agreement) throws Exception {
        try {
            Connection conn = DBConnection.getConnection();
            String sql = "UPDATE rental_agreement SET start_date = ?, end_date = ?, deposit_amount = ?, status = ? WHERE agreement_id = " + agreement.getId();

            PreparedStatement ps = conn.prepareStatement(sql);
            ps.setString(1, agreement.getStartDate().toString());
            ps.setString(2, agreement.getEndDate().toString());
            ps.setInt(3, agreement.getDepositAmount());
            ps.setString(4, agreement.getStatus());
            ps.executeUpdate();
            conn.commit();
            System.out.println("Agreement Updated");
        } catch (Exception e) {
            System.out.println("SQL : " + e.getMessage());
        }
    }


}
