package com.cts.dao;

import com.cts.db.DBConnection;
import com.cts.model.Property;
import com.cts.model.RentalAgreement;

import java.io.IOException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

public class PropertyDAO {
    public List<Property> getAllProperty() throws IOException {
        try{
            Connection conn = DBConnection.getConnection();
            String query = "SELECT * FROM property";
            PreparedStatement ps = conn.prepareStatement(query);
            ResultSet rs = ps.executeQuery();
            List<Property> propertyList = new ArrayList<Property>();

            while(rs.next()){
                int id = rs.getInt("id");
                String address = rs.getString("address");
                String type = rs.getString("property_type");
                int bathrooms = rs.getInt("bathrooms");
                int bedrooms = rs.getInt("bedrooms");
                int rateAmount = rs.getInt("rent_amount");
                propertyList.add(new Property(id, address, type, bathrooms, bedrooms, rateAmount));
            }
            return propertyList;
        } catch (SQLException e) {
            System.out.println("SQLException: " + e.getMessage());
            return new ArrayList<Property>();
        }
    }


    public void createProperty(Property property) throws IOException {
        try{
            Connection conn = DBConnection.getConnection();
            String query = "insert into property(address, property_type, bedrooms, bathrooms, rent_amount) values\n" +
                    "(?, ?, ?, ?, ?);";
            PreparedStatement ps = conn.prepareStatement(query);
            ps.setString(1, property.getAddress());
            ps.setString(2, property.getType());
            ps.setInt(3, property.getBedrooms());
            ps.setInt(4, property.getBathrooms());
            ps.setInt(5, property.getRentAmount());
            ps.executeUpdate();
            conn.commit();
            System.out.println("Property created!!!");
        }catch (SQLException e){
            System.out.println("SQLException: " + e.getMessage());
        }
    }

    public void deleteProperty(int id) throws Exception {
        try{
            Connection conn = DBConnection.getConnection();
            String query = "delete from property where id = " + id;
            PreparedStatement ps = conn.prepareStatement(query);
            ps.executeUpdate();
            conn.commit();
            System.out.println("Property with id="+id+" is DELETED!!!");
        }catch (SQLException e){
            System.out.println("SQLException: " + e.getMessage());
        }
    }


    public Property getProperty(int propertyId) throws Exception {
        String query = "select * from property where id = " + propertyId;
        PreparedStatement ps = DBConnection.getConnection().prepareStatement(query);
        ResultSet rs = ps.executeQuery();
        if(rs.next()){
            int id = rs.getInt("id");
            String address = rs.getString("address");
            String type = rs.getString("property_type");
            int bathrooms = rs.getInt("bathrooms");
            int bedrooms = rs.getInt("bedrooms");
            int rateAmount = rs.getInt("rent_amount");
            return new Property(id, address, type, bathrooms, bedrooms, rateAmount);
        }else{
            return null;
        }
    }

    public void updateProperty(Property property) throws Exception{
        try {
            Connection conn = DBConnection.getConnection();
            String sql = "UPDATE property SET address = ?, property_type = ?, bathrooms = ?, bedrooms = ?, rent_amount=? WHERE id = " + property.getId();

            PreparedStatement ps = conn.prepareStatement(sql);
            ps.setString(1, property.getAddress());
            ps.setString(2, property.getType());
            ps.setInt(3, property.getBathrooms());
            ps.setInt(4, property.getBedrooms());
            ps.setInt(5, property.getRentAmount());
            ps.executeUpdate();
            conn.commit();
            System.out.println("Property Updated!");
        }catch (Exception e){
            System.out.println("SQL : " + e.getMessage());
        }
    }

}
