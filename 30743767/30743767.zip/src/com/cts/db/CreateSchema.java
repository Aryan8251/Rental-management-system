package com.cts.db;

import java.sql.*;

public class CreateSchema {
    public static void createTables() throws ClassNotFoundException, SQLException {
        try {
            Connection conn = DBConnection.getConnection();
            conn.setAutoCommit(false);

            if(CreateSchema.doesNotTableExist(conn, "property")){
                Statement stmt = conn.createStatement();
                String query = "CREATE TABLE PROPERTY (\n" +
                        "    ID INT NOT NULL auto_increment,\n" +
                        "    ADDRESS VARCHAR(255) NOT NULL,\n" +
                        "    PROPERTY_TYPE VARCHAR(10) NOT NULL,\n" +
                        "    BEDROOMS INT NOT NULL,\n" +
                        "    BATHROOMS INT NOT NULL,\n" +
                        "    RENT_AMOUNT INT NOT NULL,\n" +
                        "    CONSTRAINT pk PRIMARY KEY (ID)\n" +
                        ")";
                stmt.executeUpdate(query);
            }

            if(CreateSchema.doesNotTableExist(conn, "tenant")){
                Statement stmt = conn.createStatement();
                String query = "create table Tenant(" +
                        "\ttenant_id int auto_increment primary key," +
                        "    name varchar(50) not null," +
                        "    phone_number varchar(10) not null unique ," +
                        "    email varchar(50) not null unique" +
                        ")";
                stmt.executeUpdate(query);
            }

            if(CreateSchema.doesNotTableExist(conn, "rental_agreement")){
                Statement stmt = conn.createStatement();
                String query = "CREATE TABLE rental_agreement (\n" +
                        "    agreement_id INT AUTO_INCREMENT PRIMARY KEY,\n" +
                        "    property_id INT NOT NULL,\n" +
                        "    tenant_id int NOT NULL,\n" +
                        "    start_date DATE NOT NULL,\n" +
                        "    end_date DATE NOT NULL,\n" +
                        "    rent_amount INT NOT NULL,\n" +
                        "    deposit_amount INT NOT NULL,\n" +
                        "    status VARCHAR(100) NOT NULL,\n" +
                        "    FOREIGN KEY fk_rental_agreement_property (property_id) REFERENCES property (id),\n" +
                        "    FOREIGN KEY fk_rental_agreement_tenant (tenant_id) REFERENCES tenant (tenant_id)\n" +
                        ")";
                stmt.executeUpdate(query);
            }
            conn.commit();
        } catch (SQLException e) {
            System.out.println("\n\nTable already exists\n\n");
            System.out.println("Sql error: " + e.getMessage());
        }
    }

    private static boolean doesNotTableExist(Connection connection, String tableName) throws SQLException {
        DatabaseMetaData metaData = connection.getMetaData();
        try (ResultSet resultSet = metaData.getTables(null, null, tableName, new String[] {"TABLE"})) {
            return !resultSet.next();
        }
    }

}
