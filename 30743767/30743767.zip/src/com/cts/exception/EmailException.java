package com.cts.exception;

public class EmailException extends Exception{
    public EmailException(){
    }
    public EmailException(String message){
        super("Email Exception: " + message);
    }
}
