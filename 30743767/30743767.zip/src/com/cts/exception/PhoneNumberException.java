package com.cts.exception;

public class PhoneNumberException extends Exception{

    public PhoneNumberException(){};

    public PhoneNumberException(String message){
        super(message);
    }
}
