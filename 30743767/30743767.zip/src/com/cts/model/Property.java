package com.cts.model;

public class Property {
    private int id;
    private String address;
    private String type;
    private int bedrooms;
    private int bathrooms;
    private int rentAmount;

    public Property(int id, String address, String type, int bedrooms, int bathrooms, int rentAmount) {
        this.id = id;
        this.address = address;
        this.type = type;
        this.bedrooms = bedrooms;
        this.bathrooms = bathrooms;
        this.rentAmount = rentAmount;
    }

    public Property(String address, String type, int bedrooms, int bathrooms, int rentAmount) {
        this.address = address;
        this.type = type;
        this.bedrooms = bedrooms;
        this.bathrooms = bathrooms;
        this.rentAmount = rentAmount;
    }

    public int getRentAmount() {
        return rentAmount;
    }

    public void setRentAmount(int rentAmount) {
        this.rentAmount = rentAmount;
    }

    public int getBathrooms() {
        return bathrooms;
    }

    public void setBathrooms(int bathrooms) {
        this.bathrooms = bathrooms;
    }

    public int getBedrooms() {
        return bedrooms;
    }

    public void setBedrooms(int bedrooms) {
        this.bedrooms = bedrooms;
    }

    public String getType() {
        return type;
    }

    public void setType(String type) {
        this.type = type;
    }

    public String getAddress() {
        return address;
    }

    public void setAddress(String address) {
        this.address = address;
    }

    public int getId() {
        return id;
    }

    @Override
    public String toString() {
        return "%-10s %-40s %-20s %-10s %-10s Rs.%10s\n".formatted( this.id, this.address, this.type, this.bathrooms, this.bedrooms, this.rentAmount + "/months");
    }

    public void setId(int id) {
        this.id = id;
    }
}
