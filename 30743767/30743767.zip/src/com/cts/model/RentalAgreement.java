package com.cts.model;

import java.time.LocalDate;
import java.time.temporal.ChronoUnit;

public class RentalAgreement {
    private int id;
    private int propertyId;
    private int tenantId;
    private LocalDate startDate;
    private LocalDate endDate;
    private int rentTotalAmount;
    private int depositAmount;
    private int toPay;
    private int rentPeriod;
    private String status = "PENDING";
    private Property property;
    private Tenant tenant;

    public RentalAgreement(Property property, Tenant tenant, LocalDate startDate, LocalDate endDate, int rentPeriod, int depositAmount) throws Exception {
        this.property = property;
        this.propertyId = property.getId();
        this.tenantId = tenant.getId();
        this.tenant = tenant;
        this.startDate = startDate;
        this.endDate = endDate;
        this.rentPeriod = rentPeriod;
        this.rentTotalAmount = (rentPeriod * property.getRentAmount());
        this.depositAmount = depositAmount;
        this.toPay = rentTotalAmount - depositAmount;

        if(toPay < 0){
            throw new Exception("Deposit Cannot be more than total rent");
        }

    }
    public RentalAgreement(int id, Property property, Tenant tenant, LocalDate startDate, LocalDate endDate, int depositAmount, String status) throws Exception {
        this.id = id;
        this.property = property;
        this.tenant = tenant;
        this.propertyId = property.getId();
        this.tenantId = tenant.getId();
        this.startDate = startDate;
        this.endDate = endDate;
        this.status = status;
        this.depositAmount = depositAmount;
        this.rentPeriod = (int) Math.max(1, Math.ceil(ChronoUnit.MONTHS.between(startDate, endDate)));
        this.rentTotalAmount = (rentPeriod * property.getRentAmount());
        this.toPay = rentTotalAmount - depositAmount;
        if(toPay < 0){
            throw new Exception("Deposit Cannot be more than total rent");
        }
    }

    public int getId() {
        return id;
    }

    public int getPropertyId() {
        return propertyId;
    }

    public void setPropertyId(int propertyId) {
        this.propertyId = propertyId;
    }

    public int getTenantId() {
        return tenantId;
    }

    public void setTenantId(int tenantId) {
        this.tenantId = tenantId;
    }

    public LocalDate getStartDate() {
        return startDate;
    }

    public void setStartDate(LocalDate startDate) {
        this.startDate = startDate;
    }

    public LocalDate getEndDate() {
        return endDate;
    }

    public void setEndDate(LocalDate endDate) {
        this.endDate = endDate;
    }

    public void setId(int id) {
        this.id = id;
    }

    public int getDepositAmount() {
        return depositAmount;
    }

    public void setDepositAmount(int depositAmount) {
        this.depositAmount = depositAmount;
    }

    public int getToPay() {
        return toPay;
    }

    public void setToPay(int toPay) {
        this.toPay = toPay;
    }

    public int getRentPeriod() {
        return rentPeriod;
    }

    public void setRentPeriod(int rentPeriod) {
        this.rentPeriod = rentPeriod;
    }

    public Property getProperty() {
        return property;
    }

    public void setProperty(Property property) {
        this.property = property;
    }

    public Tenant getTenant() {
        return tenant;
    }

    public void setTenant(Tenant tenant) {
        this.tenant = tenant;
    }

    @Override
    public String toString(){
        return "%-10s %-20s %-30s %-15s %-15s %-15s %-15s %-15s %-15s\n".formatted(this.id, this.tenant.getName(), this.property.getAddress(), this.startDate, this.endDate, this.rentTotalAmount, this.depositAmount, this.toPay, this.status);
    }

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }

    public int getRentTotalAmount(){
        return this.rentTotalAmount;
    }

    public void setRentTotalAmount(int rentTotalAmount){
        this.rentTotalAmount = rentTotalAmount;
    }
}
