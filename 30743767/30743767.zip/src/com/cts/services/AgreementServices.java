package com.cts.services;

import com.cts.model.Property;
import com.cts.model.RentalAgreement;
import com.cts.model.Tenant;
import com.cts.dao.AgreementDAO;

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.time.LocalDate;
import java.time.temporal.ChronoUnit;
import java.util.List;

public class AgreementServices {
    PropertyServices propertyServices = new PropertyServices();
    TenantServices tenantServices = new TenantServices();
    AgreementDAO agreementRepository = new AgreementDAO();
    BufferedReader br = new BufferedReader(new InputStreamReader(System.in));

    public void createAgreement() throws Exception {
        if(tenantServices.getAll().isEmpty()) {
            System.out.println("\n\nTenant are not found!\n\n");
            return;
        }

        if(propertyServices.getAll().isEmpty()) {
            System.out.println("\n\nProperties are not found!\n\n");
            return;
        }

        Property property = null;
        Tenant tenant = null;

        while(property==null){
            PropertyServices propertyServices = new PropertyServices();
            propertyServices.printAllProperties();
            System.out.println("Select Property Id: ");
            int propertyId = Integer.parseInt(br.readLine());
            property = propertyServices.getProperty(propertyId);
        }

        while(tenant==null){
            TenantServices tenantServices = new TenantServices();
            tenantServices.printAllTenants();
            System.out.println("Select Tenant Id: ");
            int tenantId = Integer.parseInt(br.readLine());
            tenant = tenantServices.getTenant(tenantId);
        }

        System.out.println("Enter Start Date (yyyy-MM-dd) : ");
        LocalDate startDate = LocalDate.parse(br.readLine());

        System.out.println("Enter End Date (yyyy-MM-dd) : ");
        LocalDate endDate = LocalDate.parse(br.readLine());

        int duration = (int) Math.max(1, Math.ceil(ChronoUnit.MONTHS.between(startDate, endDate)));;

        System.out.println("\nTOTAL RENT MONTH : " + duration);
        System.out.println("\nTOTAL RENT AMOUNT : " + duration*property.getRentAmount() + "\n");

        System.out.println("Enter Deposit Amount : ");
        int deposit = Integer.parseInt(br.readLine());

        System.out.println("Enter Status : ");
        String status = br.readLine();

        RentalAgreement rentalAgreement = new RentalAgreement(property, tenant, startDate, endDate, duration, deposit);
        rentalAgreement.setStatus(status);
        agreementRepository.createAgreement(rentalAgreement);
    }

    public void printAllAgreements() throws Exception {
        List<RentalAgreement> rentalAgreementsList = agreementRepository.getAll();
        if(rentalAgreementsList.isEmpty()){
            System.out.println("\n\nAgreements are not found!\n\n");
            return;
        }
        System.out.format("%-10s %-20s %-30s %-15s %-15s %-15s %-15s %-15s %-15s\n", "Id", "Name", "Property", "Start Date", "End Date", "Total", "Deposit", "To Pay", "Status");
        for(RentalAgreement rentalAgreement: rentalAgreementsList){
            System.out.println(rentalAgreement);
        }
    }

    public void deleteProperty() throws Exception{
        try{
            System.out.println("\nEnter the id to delete agreement: ");
            int agreementId = Integer.parseInt(br.readLine());
            agreementRepository.deleteAgreement(agreementId);
        }catch (Exception e){
            System.out.println("SQL Exception: " + e.getMessage());
        }
    }

    public RentalAgreement getAgreement(int id) throws Exception {
        return agreementRepository.getAgreement(id);
    }


    public void updateAgreement(RentalAgreement agreement) throws Exception {
        agreementRepository.updateAgreement(agreement);
    }



    public static void editRentalAgreementMenu() throws Exception {

        System.out.println("""
                \nRental Agreement Management
                
                1. Start Date
                2. End Date
                3. Deposit Amount
                4. Status
               
                """);

    }

    public void editRentalAgreementManagement() throws Exception {
        BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
        AgreementServices service = new AgreementServices();
        while(true){
            service.printAllAgreements();
            RentalAgreement agreement = null;
            while(agreement == null){
                System.out.println("Enter agreement id : " );
                int agreementId = Integer.parseInt(br.readLine());
                agreement = service.getAgreement(agreementId);
            }
            editRentalAgreementMenu();
            System.out.println("Enter option: ");
            int option = Integer.parseInt(br.readLine());
            switch (option){
                case 1:
                    System.out.println("Enter Start Date (yyyy-MM-dd) : ");
                    agreement.setStartDate(LocalDate.parse(br.readLine()));
                    updateAgreement(agreement);
                    return;
                case 2:
                    System.out.println("Enter End Date (yyyy-MM-dd) : ");
                    agreement.setEndDate(LocalDate.parse(br.readLine()));
                    updateAgreement(agreement);
                    return;
                case 3:
                    System.out.println("Enter Added Deposit Amount : ");
                    agreement.setDepositAmount(agreement.getDepositAmount() + Integer.parseInt(br.readLine()));
                    updateAgreement(agreement);
                    return;
                case 4:
                    System.out.println("Enter Status : ");
                    agreement.setStatus(br.readLine());
                    updateAgreement(agreement);
                    return;
            }
        }
    }

}
