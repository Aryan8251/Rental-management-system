package com.cts.services;

import com.cts.exception.EmailException;
import com.cts.exception.PhoneNumberException;
import com.cts.model.Property;
import com.cts.model.Tenant;
import com.cts.dao.TenantDAO;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.List;

public class TenantServices {
    TenantDAO tenantDAO = new TenantDAO();
    BufferedReader br = new BufferedReader(new InputStreamReader(System.in));

    public void createTenant() throws Exception {
        try{
            System.out.println("Enter Tenant Name: ");
            String name = br.readLine();
            System.out.println("Enter Phone Number(10 digits): ");
            String phone = br.readLine();
            if(phone.length() != 10){
                throw new PhoneNumberException("Phone number should be of 10 digits");
            }
            System.out.println("Enter Email Address: ");
            String email = br.readLine();
            if(email.length() < 5 || !email.contains("@")){
                throw new EmailException("Email address is too short");
            }
            Tenant tenant  = new Tenant(name, phone, email);
            tenantDAO.createTenant(tenant);
        }catch (EmailException e){
            System.err.println(e.getMessage());
        }catch (PhoneNumberException e){
            System.err.println(e.getMessage());
        }

    }

    public void printAllTenants() throws IOException {
        List<Tenant> tenantList = tenantDAO.getAllTenant();
        if(!tenantList.isEmpty()){
            System.out.println("\n\nTenant List");
            System.out.format("\n%-10s %-30s %-20s %-20s\n", "Id", "Name", "Phone", "Email");
            for(Tenant tenant : tenantList) {
                System.out.println(tenant);
            }
        }else{
            System.out.println("\n\nNo tenants found");
        }
    }

    public void deleteTenant() throws Exception{
        printAllTenants();
        System.out.println("\nENTER ID OF PROPERTY TO DELETE: ");
        int id = Integer.parseInt(br.readLine());
        tenantDAO.deleteTenant(id);
    }

    public Tenant getTenant(int id) throws Exception{
        return tenantDAO.getTenant(id);
    }

    public List<Tenant> getAll() throws Exception{
        return tenantDAO.getAllTenant();
    }

    public void updateTenant(Tenant tenant) throws Exception{
        tenantDAO.updateTenant(tenant);
    }


    public static void editTenantMenu() throws Exception {

        System.out.println("""
                \nRental Tenant Management
                
                1. Name
                2. Email
                3. Phone Number
                0. Return
               
                """);

    }

    public void editTenantManagement() throws Exception {
        BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
        while (true) {
            printAllTenants();
            Tenant tenant = null;
            while (tenant == null) {
                System.out.println("Enter tenant id : ");
                int tenantId = Integer.parseInt(br.readLine());
                tenant = getTenant(tenantId);
            }
            editTenantMenu();
            System.out.println("Enter option: ");
            int option = Integer.parseInt(br.readLine());
            switch (option) {
                case 1:
                    System.out.println("Enter Name : ");
                    tenant.setName(br.readLine());
                    updateTenant(tenant);
                    return;
                case 2:
                    System.out.println("Enter Email : ");
                    tenant.setEmail(br.readLine());
                    updateTenant(tenant);
                    return;
                case 3:
                    System.out.println("Enter Phone Number : ");
                    tenant.setContactNumber(br.readLine());
                    updateTenant(tenant);
                    return;
                case 0:
                    System.out.println("Returning....\n\n");
                    return;
                default:
                    System.out.println("Invalid option");
            }
        }
    }
}
